package com.mycompany.eventconnect;

public class Attendee extends User {

    public Attendee(String id, String name, String email, String password) {
        super(id, name, email, password);
    }
}