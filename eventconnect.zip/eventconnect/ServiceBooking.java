package com.mycompany.eventconnect;

public class ServiceBooking {
    private String service;
    private String details;

    public ServiceBooking(String service, String details) {
        this.service = service;
        this.details = details;
    }

    @Override
    public String toString() {
        return service + ": " + details;
    }
}
