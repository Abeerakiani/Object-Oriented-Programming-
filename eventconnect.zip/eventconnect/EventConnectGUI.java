package com.mycompany.eventconnect;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class EventConnectGUI extends JFrame {

    // USERS
    Admin admin =
            new Admin("A1", "Admin", "admin@gmail.com", "1234");

    Organizer organizer =
            new Organizer("O1", "Organizer", "org@gmail.com", "1234");

    Attendee attendee =
            new Attendee("T1", "Attendee", "att@gmail.com", "1234");

    // EVENTS
    Event[] events = new Event[50];
    int eventCount = 1;

    // COLORS
    Color dark   = new Color(15, 15, 25);
    Color card   = new Color(35, 35, 50);
    Color neon   = new Color(0, 255, 170);
    Color purple = new Color(120, 80, 255);
    Color red    = new Color(220, 50, 80);
    Color orange = new Color(255, 140, 0);

    // COMPONENTS
    JTextField emailField;
    JPasswordField passwordField;

    JTable table;
    DefaultTableModel model;

    public EventConnectGUI() {

        events[0] = new Event("E01", "Music Festival", "12-12-2026", 100, 50);

        setTitle("EventConnect Ultimate");
        setSize(1100, 650);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        loginScreen();
        setVisible(true);
    }

    // ====================================================
    // LOGIN SCREEN
    // ====================================================
    void loginScreen() {

        JPanel bg = new JPanel(null);
        bg.setBackground(dark);

        JLabel title = new JLabel("EVENT CONNECT");
        title.setForeground(neon);
        title.setFont(new Font("Orbitron", Font.BOLD, 40));
        title.setBounds(320, 40, 500, 60);

        JPanel cardPanel = new JPanel(null);
        cardPanel.setBounds(320, 150, 420, 320);
        cardPanel.setBackground(card);
        cardPanel.setBorder(new LineBorder(neon, 3));

        JLabel email = new JLabel("Email");
        email.setForeground(Color.WHITE);
        email.setBounds(40, 40, 100, 30);

        emailField = new JTextField();
        emailField.setBounds(40, 70, 320, 40);
        styleField(emailField);

        JLabel pass = new JLabel("Password");
        pass.setForeground(Color.WHITE);
        pass.setBounds(40, 130, 100, 30);

        passwordField = new JPasswordField();
        passwordField.setBounds(40, 160, 320, 40);
        styleField(passwordField);

        JButton loginBtn = new JButton("LOGIN");
        loginBtn.setBounds(100, 240, 200, 45);
        styleButton(loginBtn, purple);
        loginBtn.addActionListener(e -> login());

        cardPanel.add(email);
        cardPanel.add(emailField);
        cardPanel.add(pass);
        cardPanel.add(passwordField);
        cardPanel.add(loginBtn);

        bg.add(title);
        bg.add(cardPanel);

        setContentPane(bg);
        revalidate();
    }

    // ====================================================
    // LOGIN LOGIC
    // ====================================================
    void login() {
        String email = emailField.getText();
        String pass  = String.valueOf(passwordField.getPassword());

        if (admin.login(email, pass))         dashboard("ADMIN");
        else if (organizer.login(email, pass)) dashboard("ORGANIZER");
        else if (attendee.login(email, pass))  dashboard("ATTENDEE");
        else JOptionPane.showMessageDialog(this, "Invalid Login!");
    }

    // ====================================================
    // DASHBOARD
    // ====================================================
    void dashboard(String role) {

        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(dark);

        // SIDEBAR
        JPanel side = new JPanel();
        side.setPreferredSize(new Dimension(230, 0));
        side.setBackground(card);
        side.setLayout(new GridLayout(12, 1, 10, 10));
        side.setBorder(new EmptyBorder(20, 15, 20, 15));

        JLabel logo = new JLabel(role + " PANEL");
        logo.setForeground(neon);
        logo.setFont(new Font("Orbitron", Font.BOLD, 22));

        JButton createBtn  = new JButton("+ Create Event");
        JButton viewBtn    = new JButton("View Details");
        JButton updateBtn  = new JButton("Update Event");
        JButton deleteBtn  = new JButton("Delete Event");
        JButton serviceBtn = new JButton("Book Service");
        JButton ticketBtn  = new JButton("Buy Tickets");
        JButton refreshBtn = new JButton("Refresh");
        JButton logoutBtn  = new JButton("Logout");

        styleButton(createBtn,  purple);
        styleButton(viewBtn,    new Color(0, 150, 200));
        styleButton(updateBtn,  orange);
        styleButton(deleteBtn,  red);
        styleButton(serviceBtn, purple);
        styleButton(ticketBtn,  purple);
        styleButton(refreshBtn, purple);
        styleButton(logoutBtn,  new Color(80, 80, 80));

        side.add(logo);

        if (role.equals("ADMIN")) {
            side.add(createBtn);
            side.add(viewBtn);
            side.add(updateBtn);
            side.add(deleteBtn);
        }

        if (role.equals("ORGANIZER")) {
            side.add(viewBtn);
            side.add(serviceBtn);
        }

        if (role.equals("ATTENDEE")) {
            side.add(viewBtn);
            side.add(ticketBtn);
        }

        side.add(refreshBtn);
        side.add(logoutBtn);

        // CENTER TABLE
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(dark);

        JLabel heading = new JLabel("EVENT MANAGEMENT SYSTEM");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("Arial", Font.BOLD, 28));
        heading.setBorder(new EmptyBorder(20, 20, 20, 20));

        String[] cols = {"Index", "ID", "Name", "Date", "Tickets", "Price"};

        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };

        table = new JTable(model);
        table.setBackground(card);
        table.setForeground(Color.WHITE);
        table.setFont(new Font("Arial", Font.PLAIN, 16));
        table.setRowHeight(30);
        table.getTableHeader().setBackground(new Color(20, 20, 40));
        table.getTableHeader().setForeground(neon);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 15));
        table.setSelectionBackground(purple);
        table.setSelectionForeground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(dark);

        refreshTable();

        center.add(heading, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        main.add(side, BorderLayout.WEST);
        main.add(center, BorderLayout.CENTER);

        // ACTIONS
        createBtn.addActionListener(e  -> createEvent());
        viewBtn.addActionListener(e    -> viewEvent());
        updateBtn.addActionListener(e  -> updateEvent());
        deleteBtn.addActionListener(e  -> deleteEvent());
        serviceBtn.addActionListener(e -> serviceDialog());
        ticketBtn.addActionListener(e  -> buyTickets());
        refreshBtn.addActionListener(e -> refreshTable());
        logoutBtn.addActionListener(e  -> loginScreen());

        setContentPane(main);
        revalidate();
    }

    // ====================================================
    // CREATE EVENT  (C)
    // ====================================================
    void createEvent() {

        JTextField id      = new JTextField();
        JTextField name    = new JTextField();
        JTextField date    = new JTextField();
        JTextField tickets = new JTextField();
        JTextField price   = new JTextField();

        Object[] fields = {
            "ID:", id,
            "Name:", name,
            "Date (DD-MM-YYYY):", date,
            "Tickets:", tickets,
            "Price ($):", price
        };

        int result = JOptionPane.showConfirmDialog(this, fields, "Create Event", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            if (id.getText().trim().isEmpty() || name.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "ID and Name cannot be empty!"); return;
            }
            try {
                int t    = Integer.parseInt(tickets.getText().trim());
                double p = Double.parseDouble(price.getText().trim());
                events[eventCount++] = new Event(
                    id.getText().trim(), name.getText().trim(),
                    date.getText().trim(), t, p
                );
                refreshTable();
                JOptionPane.showMessageDialog(this, "Event Created Successfully!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Tickets must be a whole number, Price must be a number!");
            }
        }
    }

    // ====================================================
    // VIEW EVENT DETAILS  (R)
    // ====================================================
    void viewEvent() {

        int idx = getSelectedIndex();
        if (idx < 0) return;

        Event e = events[idx];

        String info =
            "===================================\n" +
            "  EVENT DETAILS\n" +
            "===================================\n" +
            "  ID       : " + e.getId()       + "\n" +
            "  Name     : " + e.getName()     + "\n" +
            "  Date     : " + e.getDate()     + "\n" +
            "  Tickets  : " + e.getTickets()  + "\n" +
            "  Price    : $" + String.format("%.2f", e.getTicketPrice()) + "\n" +
            "===================================\n" +
            "  SERVICES\n" +
            "===================================\n" +
            e.servicesInfo();

        JTextArea area = new JTextArea(info);
        area.setEditable(false);
        area.setBackground(card);
        area.setForeground(neon);
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));
        area.setBorder(new EmptyBorder(10, 10, 10, 10));

        JOptionPane.showMessageDialog(this, new JScrollPane(area),
            "Event Details — " + e.getName(), JOptionPane.PLAIN_MESSAGE);
    }

    // ====================================================
    // UPDATE EVENT  (U)
    // ====================================================
    void updateEvent() {

        int idx = getSelectedIndex();
        if (idx < 0) return;

        Event e = events[idx];

        JTextField name    = new JTextField(e.getName());
        JTextField date    = new JTextField(e.getDate());
        JTextField tickets = new JTextField(String.valueOf(e.getTickets()));
        JTextField price   = new JTextField(String.valueOf(e.getTicketPrice()));

        Object[] fields = {
            "Name:", name,
            "Date (DD-MM-YYYY):", date,
            "Tickets:", tickets,
            "Price ($):", price
        };

        int result = JOptionPane.showConfirmDialog(this, fields,
            "Update Event — " + e.getId(), JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            if (name.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Name cannot be empty!"); return;
            }
            try {
                int t    = Integer.parseInt(tickets.getText().trim());
                double p = Double.parseDouble(price.getText().trim());

                e.setName(name.getText().trim());
                e.setDate(date.getText().trim());
                e.setTickets(t);
                e.setTicketPrice(p);

                refreshTable();
                JOptionPane.showMessageDialog(this, "Event Updated Successfully!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Tickets must be a whole number, Price must be a number!");
            }
        }
    }

    // ====================================================
    // DELETE EVENT  (D)
    // ====================================================
    void deleteEvent() {

        int idx = getSelectedIndex();
        if (idx < 0) return;

        Event e = events[idx];

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete:\n\n  " + e.getName() + " (" + e.getId() + ")?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            // Shift array left to fill gap
            for (int i = idx; i < eventCount - 1; i++) events[i] = events[i + 1];
            events[--eventCount] = null;

            refreshTable();
            JOptionPane.showMessageDialog(this, "Event Deleted Successfully!");
        }
    }

    // ====================================================
    // HELPER: get selected row index (table click or manual input)
    // ====================================================
    int getSelectedIndex() {

        int row = table.getSelectedRow();
        if (row >= 0) return (int) model.getValueAt(row, 0);

        String idxStr = JOptionPane.showInputDialog(this,
            "Click a row in the table, or type an Event Index (0 to " + (eventCount - 1) + "):");

        if (idxStr == null || idxStr.trim().isEmpty()) return -1;

        try {
            int idx = Integer.parseInt(idxStr.trim());
            if (idx < 0 || idx >= eventCount) {
                JOptionPane.showMessageDialog(this, "Invalid index! Valid range: 0 to " + (eventCount - 1));
                return -1;
            }
            return idx;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number!");
            return -1;
        }
    }

    // ====================================================
    // BUY TICKETS
    // ====================================================
    void buyTickets() {

        int idx = getSelectedIndex();
        if (idx < 0) return;

        String qtyStr = JOptionPane.showInputDialog(this, "Enter Ticket Quantity:");
        if (qtyStr == null) return;

        try {
            int qty  = Integer.parseInt(qtyStr.trim());
            Event e  = events[idx];

            if (qty <= 0) { JOptionPane.showMessageDialog(this, "Quantity must be greater than 0!"); return; }
            if (qty > e.getTickets()) { JOptionPane.showMessageDialog(this, "Not enough tickets! Available: " + e.getTickets()); return; }

            double total = qty * e.getTicketPrice();
            e.setTickets(e.getTickets() - qty);

            refreshTable();
            JOptionPane.showMessageDialog(this,
                "Purchase Successful!\n\nEvent: " + e.getName() +
                "\nQuantity: " + qty + "\nTotal: $" + String.format("%.2f", total));

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number!");
        }
    }

    // ====================================================
    // SERVICES
    // ====================================================
    void serviceDialog() {

        int idx = getSelectedIndex();
        if (idx < 0) return;

        String[] options = {"Place", "Bus", "Venue", "Meal", "Decoration"};

        String type = (String) JOptionPane.showInputDialog(this,
            "Select Service", "Service", JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (type == null) return;

        String details = JOptionPane.showInputDialog(this, "Enter Details:");
        if (details == null) return;

        organizer.bookService(events[idx], type, details);

        JOptionPane.showMessageDialog(this,
            "Service Added!\n\n" + events[idx].servicesInfo());
    }

    // ====================================================
    // REFRESH TABLE
    // ====================================================
    void refreshTable() {

        model.setRowCount(0);

        for (int i = 0; i < eventCount; i++) {
            Event e = events[i];
            model.addRow(new Object[]{
                i, e.getId(), e.getName(), e.getDate(),
                e.getTickets(), "$" + String.format("%.2f", e.getTicketPrice())
            });
        }
    }

    // ====================================================
    // STYLE BUTTON
    // ====================================================
    void styleButton(JButton btn, Color bg) {

        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Arial", Font.BOLD, 15));
        btn.setBorder(new LineBorder(neon, 2));

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(neon);  btn.setForeground(Color.BLACK); }
            public void mouseExited (MouseEvent e) { btn.setBackground(bg);    btn.setForeground(Color.WHITE); }
        });
    }

    // ====================================================
    // STYLE FIELD
    // ====================================================
    void styleField(JTextField field) {
        field.setBackground(new Color(50, 50, 70));
        field.setForeground(Color.WHITE);
        field.setCaretColor(neon);
        field.setFont(new Font("Arial", Font.PLAIN, 16));
        field.setBorder(new LineBorder(neon, 2));
    }

    // ====================================================
    // MAIN
    // ====================================================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EventConnectGUI());
    }
}
