package com.mycompany.eventconnect;

public class Organizer extends User {

    public Organizer(String id, String name, String email, String password) {
        super(id, name, email, password);
    }

    public void bookService(Event e, String type, String details) {

        switch (type) {

            case "Place" -> e.setPlace(details);

            case "Bus" -> e.setBus(details);

            case "Venue" -> e.setVenue(details);

            case "Meal" -> e.setMeal(details);

            case "Decoration" -> e.setDecoration(details);
        }
    }
}