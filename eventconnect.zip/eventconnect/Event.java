package com.mycompany.eventconnect;

public class Event {

    private String id;
    private String name;
    private String date;
    private int tickets;
    private double ticketPrice;

    private String place      = "Not Booked";
    private String bus        = "Not Booked";
    private String venue      = "Not Booked";
    private String meal       = "Not Booked";
    private String decoration = "Not Booked";

    public Event(String id, String name, String date, int tickets, double ticketPrice) {
        this.id          = id;
        this.name        = name;
        this.date        = date;
        this.tickets     = tickets;
        this.ticketPrice = ticketPrice;
    }

    // ── GETTERS ──────────────────────────────────────
    public String getId()          { return id; }
    public String getName()        { return name; }
    public String getDate()        { return date; }
    public int    getTickets()     { return tickets; }
    public double getTicketPrice() { return ticketPrice; }

    // ── SETTERS ──────────────────────────────────────
    public void setName(String name)              { this.name        = name; }
    public void setDate(String date)              { this.date        = date; }
    public void setTickets(int tickets)           { this.tickets     = tickets; }
    public void setTicketPrice(double ticketPrice){ this.ticketPrice = ticketPrice; }

    public void setPlace(String place)            { this.place       = place; }
    public void setBus(String bus)                { this.bus         = bus; }
    public void setVenue(String venue)            { this.venue       = venue; }
    public void setMeal(String meal)              { this.meal        = meal; }
    public void setDecoration(String decoration)  { this.decoration  = decoration; }

    // ── SERVICES INFO ─────────────────────────────────
    public String servicesInfo() {
        return "  Place      : " + place      + "\n" +
               "  Bus        : " + bus        + "\n" +
               "  Venue      : " + venue      + "\n" +
               "  Meal       : " + meal       + "\n" +
               "  Decoration : " + decoration;
    }

    @Override
    public String toString() {
        return id + " | " + name + " | " + date +
               " | Tickets: " + tickets +
               " | Price: $" + ticketPrice;
    }
}
